    int expected[DATA_SIZE];
    expected[0] = in1[0];
    for (int i = 1; i < DATA_SIZE; i++)
    {
        expected[i] = in1[i] + expected[i-1];
        if (out[i] != expected[i])
        {
            std::cout << "Error: Result mismatch" << std::endl;
            std::cout << "i = " << i << " CPU result = " << expected[i] << " Device result = " << out[i] << std::endl;
            match = false;
            break;
        }
    }