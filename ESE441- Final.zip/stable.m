eq_point = [0;pi;0;0];

cartpendulum_stablized = @(t,x) [x(3);
                       x(4);
                       (l*m2*sin(x(2))*x(4)^2 - (F*(x-eq_point)) + m2*g*cos(x(2))*sin(x(2)))/(m1+m2*(1 - cos(x(2))^2));
                       -1*(l*m2*cos(x(2))*sin(x(2))*x(4)^2 - (F*(x-eq_point))*cos(x(2))+ (m1 + m2)*g*sin(x(2)))/(l*m1 + l*m2*(1 - cos(x(2))^2))];

[t,x_traj] = ode45(cartpendulum_stablized,[0,15],[0;pi+0.1;0;0]);
