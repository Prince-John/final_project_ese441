extern "C" {
	void prefixSum(
	        const unsigned int *in1, // Read-Only Vector 1
	        unsigned int *out      // Output Result
	       )
	{
		const unsigned int size = 256;// Size in integer
		unsigned int data0[size];
		unsigned int data1[size];
#pragma HLS array_partition variable=in1 type = complete  
#pragma HLS array_partition variable=data0 type = complete  
#pragma HLS array_partition variable=data1 type = complete  
#pragma HLS array_partition variable=out type = complete 
#pragma HLS INTERFACE m_axi port=in1 bundle=aximm1
#pragma HLS INTERFACE m_axi port=out bundle=aximm1
		
		//Starting the loading into a fully partitioned buffer. 
		
		for(int i = 0; i < size; i++){
			#pragma HLS unroll	
			data1[i] = in1[i];
		}	
		

		//j = 0
		for(int i = 0; i < size; i++){
			
			#pragma HLS unroll	
			if(i<1){
				
				data0[i] = data1[i];						
			}
			else{
				data0[i] = data1[i] + data1[i - 1];
			}
		}
		//j = 1
		for(int i = 0; i < size; i++){
		
			#pragma HLS unroll	
			if(i<2){
				
				data1[i] = data0[i];						
			}
			else{
				data1[i] = data0[i] + data0[i - 2];
			}
		}
		//j = 2
		for (int i = 0; i < size; i++) {

			#pragma HLS unroll	
			if (i < 4) {

				data0[i] = data1[i];
			}
			else {
				data0[i] = data1[i] + data1[i - 4];
			}
		}
		//j = 3
		for (int i = 0; i < size; i++) {

			#pragma HLS unroll	
			if (i < 8) {

				data1[i] = data0[i];
			}
			else {
				data1[i] = data0[i] + data0[i - 8];
			}
		}
		//j = 4
		for (int i = 0; i < size; i++) {

		#pragma HLS unroll 		
			if (i < 16) {

				data0[i] = data1[i];
			}
			else {
				data0[i] = data1[i] + data1[i - 16];
			}
		}
		//j = 5
		for (int i = 0; i < size; i++) {

		#pragma HLS unroll		
			if (i < 32) {

				data1[i] = data0[i];
			}
			else {
				data1[i] = data0[i] + data0[i - 32];
			}
		}
		//j = 6
		for (int i = 0; i < size; i++) {

		#pragma HLS unroll		
			if (i < 64) {

				data0[i] = data1[i];
			}
			else {
				data0[i] = data1[i] + data1[i - 64];
			}
		}
		//j = 7
		for (int i = 0; i < size; i++) {

		#pragma HLS unroll 		
			if (i < 128) {

				data1[i] = data0[i];
			}
			else {
				data1[i] = data0[i] + data0[i - 128];
			}
		}
		
		//Output write to the buffer
		for (int i = 0; i < size; i++) {
		#pragma HLS unroll		
			out[i] = data1[i];
		}
	    
	}
}

